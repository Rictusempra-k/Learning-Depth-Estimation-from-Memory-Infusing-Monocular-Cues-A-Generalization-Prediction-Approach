import numpy as np
import os
import scipy.io as sio

# kitti_train_npy = np.load("E:/pyproject/AMDEN/data/mat/kitti_train.npy",allow_pickle=True)
# _kitti_train = kitti_train_npy.tolist()

import cv2
import scipy.io as sio

# a = cv2.imread('E:\\pyproject\\datasets\\KITTI2012\\PNGImages\\000105.png')
# b = cv2.rectangle(a, (974, 97), (1226, 373), (230, 182, 65), 3)
# b = cv2.rectangle(b, (530, 176), (553, 194), (230, 182, 65), 3)
# cv2.imshow('bb', b)
# cv2.waitKey(0)
# print('a')
# city_val = sio.loadmat("E:/pyproject/AMDEN/data/mat/city_val.mat") # all val
#
# kitti_val = sio.loadmat("E:/pyproject/AMDEN/data/mat/kitti_val.mat")  # kitti all train data
# img = kitti_val['000112.png']
# print('a')


# city_train_npy = np.load("E:/pyproject/AMDEN/data/mat/city_train.npy", allow_pickle=True)
# city_train_npy_new = np.load("E:/pyproject/amden_new/data/mat/city_train_new.npy", allow_pickle=True)
# city_val_npy = np.load("E:/pyproject/AMDEN/data/mat/city_val.npy", allow_pickle=True)
# city_val_npy_new = np.load("E:/pyproject/amden_new/data/mat/city_val_new.npy", allow_pickle=True)
# print('a')
#
#
#
#
# def MAEs(pds, gds):
#     mae = 0  # abs rel
#     aqrel = 0
#     rmse = 0
#     logrmse = 0
#     ard = 0
#     count = 0
#     di_count = 0
#     log_count = 0
#     the1, the2, the3 = 0, 0, 0
#     for i, pd in enumerate(pds):
#         if gds[i] < 1000:
#             if gds[i] == 0:
#                 gds[i] += 10e-8
#             mae += abs(pd - gds[i])
#             rmse += (pd - gds[i]) ** 2
#
#             if gds[i] <= 0.1:
#                 di_count += 1
#             else:
#                 aqrel += abs(pd - gds[i]) ** 2 / gds[i]
#                 ard += abs(pd - gds[i]) / gds[i]
#             if gds[i] < 1:
#                 log_count += 1
#             else:
#                 logrmse += (np.log(pd) - np.log(gds[i])) ** 2
#             # threshold = 1.25 1.25**2 1.25**3
#             if pd / gds[i] < 1.25:
#                 the1 += 1
#             if pd / gds[i] < 1.25 ** 2:
#                 the2 += 1
#             if pd / gds[i] < 1.25 ** 3:
#                 the3 += 1
#             count += 1
#     print("count", ard, count)
#     print("MAE:", mae / count)
#     print("RMSE:", np.sqrt(rmse / count))
#     print("Log RMSE:", np.sqrt(logrmse / (count - log_count)))
#     print("ARD/AbsRel:", ard / (count - di_count))
#     print("aqrel", aqrel / (count - di_count))
#     print("Threshold", the1 / count, the2 / count, the3 / count)
#     com_acc(pds, gds)
#
#
# def com_acc(pre, rea):
#     '''
#     pre [[x, y, z], [x, y, z], ...]
#     '''
#     count = 0
#     acc_list = [0 for _ in range(6)]
#     for i, data in enumerate(pre):
#         pd = data
#         gd = rea[i]
#
#         count += 1
#         for i, zeta in enumerate([0.05, 0.1, 0.15, 0.2, 0.25, 0.3]):
#             if abs(gd - pd)/gd < zeta:
#                 acc_list[i] += 1
#     acc = [a/count for a in acc_list]
#     print("Acc:", acc)
#
#
# pd = np.load('E:\\pyproject\\AMDEN\\data\\result_pre.npy')
# gd = np.load('E:\\pyproject\\AMDEN\\data\\result_rea.npy')
#
#
#
# pos_25 = np.where(gd <= 25)
# MAEs(list(pd[pos_25]), list(gd[pos_25]))
#
# pos_50 = np.where((gd <= 50) & (gd > 25))
# MAEs(list(pd[pos_50]), list(gd[pos_50]))
#
# pos_100 = np.where(gd <= 100 & (gd > 50))
# MAEs(list(pd[pos_100]), list(gd[pos_100]))
#
# print('a')

# kitti_memory_0323 = np.load("E:\\pyproject\\AMDEN\\data\\mat\\kitti_memory100_z_random.npy", allow_pickle=True)
# temp = kitti_memory_0323[0, :]
# kitti_memory_0323 = []
# for i in range(10):
#     kitti_memory_0323.append(temp)
# kitti_memory_0323_fuben = np.load("E:\\pyproject\\AMDEN\\data\\mat\\kitti_memory100_z - 副本.npy", allow_pickle=True)

# city_memoey = np.load("E:\\pyproject\\AMDEN\\data\\mat\\city_memory.npy", allow_pickle=True)
# kitti_memory_0323 = kitti_memory_0323[80:81, :]
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\kitti_memory100.npy", kitti_memory_0323)

# flag = 0



# np.save("E:\\pyproject\\AMDEN\\data\\mat\\kitti_memory100_z_random_same.npy", kitti_memory_0323)


# memory = kitti_memory_0323.copy()
# import random
# random.shuffle(memory)
# memory_100 = []
# memory_200 = []
# memory_300 = []
# memory_400 = []
# memory_500 = []
# memory_600 = []
# memory_700 = []
# memory_800 = []
# memory_900 = []
#
# memory_0 = []
# memory_10 = memory[0:10, :]
# memory_50 = memory[0:50, :]
# memory_100 = memory[0:100, :]
# memory_200 = memory[0:200, :]
# memory_300 = memory[0:300, :]
# memory_400 = memory[0:400, :]
# memory_500 = memory[0:500, :]
# memory_600 = memory[0:600, :]
# memory_700 = memory[0:700, :]
# memory_800 = memory[0:800, :]
# memory_900 = memory[0:900, :]
# memory_1000 = memory
#
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_0.npy", memory_0)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_10.npy", memory_10)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_50.npy", memory_50)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_100.npy", memory_100)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_200.npy", memory_200)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_300.npy", memory_300)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_400.npy", memory_400)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_500.npy", memory_500)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_600.npy", memory_600)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_700.npy", memory_700)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_800.npy", memory_800)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_900.npy", memory_900)
#
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_1000.npy", memory_1000)


# print(flag)
# print(flag)
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\city_memory.npy", city_memoey)




# memory = np.load('E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_1000.npy', allow_pickle=True)
# memory = np.load('E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_random_500.npy', allow_pickle=True)
# value = np.zeros((500, 1))
# dis = np.zeros((500, 1))
# box = np.zeros((500, 4))
# for i in range(len(memory)):
#     dis[i, 0] = memory[i, 1][0][0]
#     value[i, 0] = memory[i, 2]
#     box[i, 0:4] = memory[i, 4]
# sio.savemat('F:\\CVPR_code_slim\\data\\memory_visualization\\mat\\data.mat', {'value':value, 'dis': dis, 'box': box})
#
# int_fun = lambda x_list: [int(x) for x in x_list]
# def draw_box(_im, bbox, color_box=(0, 0, 0), thick_bbox=2, thick_circle=8):
#     bbox = int_fun(bbox)
#     im_box = cv2.rectangle(_im, (bbox[0], bbox[1]), (bbox[2], bbox[3]), color=color_box, thickness=thick_bbox)
#     im_box = cv2.circle(im_box, (bbox[0], bbox[1]), thick_circle, (0, 255, 0), -1)
#     im_box = cv2.circle(im_box, (bbox[0], bbox[3]), thick_circle, (0, 255, 0), -1)
#     im_box = cv2.circle(im_box, (bbox[2], bbox[1]), thick_circle, (0, 255, 0), -1)
#     im_box = cv2.circle(im_box, (bbox[2], bbox[3]), thick_circle, (0, 255, 0), -1)
#
#     im_box = cv2.circle(im_box, (bbox[0], bbox[1]), thick_circle, (0, 0, 0), 1)
#     im_box = cv2.circle(im_box, (bbox[0], bbox[3]), thick_circle, (0, 0, 0), 1)
#     im_box = cv2.circle(im_box, (bbox[2], bbox[1]), thick_circle, (0, 0, 0), 1)
#     im_box = cv2.circle(im_box, (bbox[2], bbox[3]), thick_circle, (0, 0, 0), 1)
#     return im_box
#
# max_thresh = np.max(memory[:, 2])
# count1 = 0
# count2 = 0
# count3 = 0
# memory_low = []
# memory_mid = []
# memory_high = []
# dis1 = 0
# dis2 = 0
# dis3 = 0
# for i in range(len(memory)):
#     if memory[i, 2] <= max_thresh/200:
#         count1 += 1
#         dis1 += memory[i, 1]
#         memory_low.append(memory[i, :])
#     elif memory[i, 2] > max_thresh/200 and memory[i, 2] < max_thresh/20:
#         count2 += 1
#         memory_mid.append(memory[i, :])
#         dis2 += memory[i, 1]
#     else:
#         count3 += 1
#         memory_high.append(memory[i, :])
#         dis3 += memory[i, 1]
#
# print(dis1/count1, dis2/count2, dis3/count3)
# print(count1, count2, count3)
#
# memory_low = np.array(memory_low)
# memory_low = np.resize(memory_low, (-1, 5))
# np.save('E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_low.npy', memory_low)
# for i in range(len(memory_low)):
#     memory = memory_low
#     print('sample{}'.format(i), memory[i, 1], memory[i, 2])
#     im_name = memory[i, 3]
#     bbox = memory[i, 4]
#     pre_box = (bbox[0], bbox[1], bbox[2], bbox[3]) #kitti
#     img = cv2.imread(im_name)
#     img = draw_box(img, pre_box[:4], color_box=(0, 0, 0), thick_bbox=2)
#     cv2.imwrite(os.path.join('F:\\CVPR_code_slim\\data\\memory_visualization\\low\\', im_name.split('\\')[-1]), img)
#
# memory_mid = np.array(memory_mid)
# memory_mid = np.resize(memory_mid, (-1, 5))
# np.save('E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_mid.npy', memory_mid)
# for i in range(len(memory_mid)):
#     memory = memory_mid
#     print('sample{}'.format(i), memory[i, 1], memory[i, 2])
#     im_name = memory[i, 3]
#     bbox = memory[i, 4]
#     pre_box = (bbox[0], bbox[1], bbox[2], bbox[3]) #kitti
#     img = cv2.imread(im_name)
#     img = draw_box(img, pre_box[:4], color_box=(0, 0, 0), thick_bbox=2)
#     cv2.imwrite(os.path.join('F:\\CVPR_code_slim\\data\\memory_visualization\\mid\\', im_name.split('\\')[-1]), img)
#
# memory_high = np.array(memory_high)
# memory_high = np.resize(memory_high, (-1, 5))
# np.save('E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_high.npy', np.array(memory_high))
# for i in range(len(memory_high)):
#     memory = memory_high
#     print('sample{}'.format(i), memory[i, 1], memory[i, 2])
#     im_name = memory[i, 3]
#     bbox = memory[i, 4]
#     pre_box = (bbox[0], bbox[1], bbox[2], bbox[3]) #kitti
#     img = cv2.imread(im_name)
#     img = draw_box(img, pre_box[:4], color_box=(0, 0, 0), thick_bbox=2)
#     cv2.imwrite(os.path.join('F:\\CVPR_code_slim\\data\\memory_visualization\\high\\', im_name.split('\\')[-1]), img)
#
# print('end')

# look insides


# data_low = np.load('E:\\pyproject\\AMDEN\\data\\mat\\memories\\acc_num_low.npy')
# data_high = np.load('E:\\pyproject\\AMDEN\\data\\mat\\memories\\acc_num_high.npy')
# data_mid = np.load('E:\\pyproject\\AMDEN\\data\\mat\\memories\\acc_num_mid.npy')
# sio.savemat('F:\\CVPR_code_slim\\data\\memory_visualization\\mat\\data2.mat', {'data_low': data_low, 'data_high': data_high, 'data_mid': data_mid})

# diff_low_high = sio.loadmat("F:\\CVPR_code_slim\\data\\memory_visualization\\mat\\diff_low_high.mat")
# lh_number = list(diff_low_high['diff_lh'][0])
# mem = np.load("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_random_500.npy", allow_pickle=True)
# mem_new = []
# for i in range(300):
#     if mem[i, 1][0][0]<=70 and mem[i, 1][0][0]>=50:
#         mem_new.append(mem[i, :])
#
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\same_distribution.npy", np.array(mem_new))
#
#
# print('a')

def com_acc(pre, rea):
    '''
    pre [[x, y, z], [x, y, z], ...]
    '''
    count = 0
    acc_list = [0 for _ in range(6)]
    for i, data in enumerate(pre):
        pd = data
        gd = rea[i]
        count += 1
        for i, zeta in enumerate([0.05, 0.1, 0.15, 0.2, 0.25, 0.3]):
            if abs(gd - pd) / gd < zeta:
                acc_list[i] += 1
    acc = [a / count for a in acc_list]
    print("Acc:", acc)

def MAEs(pds, gds):
    mae = 0  # abs rel
    aqrel = 0
    rmse = 0
    logrmse = 0
    ard = 0
    count = 0
    di_count = 0
    log_count = 0
    the1, the2, the3 = 0, 0, 0
    for i, pd in enumerate(pds):
        if gds[i] < 80:
            if gds[i] == 0:
                gds[i] += 10e-8
            mae += abs(pd - gds[i])
            rmse += (pd - gds[i]) ** 2

            if gds[i] <= 0.1:
                di_count += 1
            else:
                aqrel += abs(pd - gds[i]) ** 2 / gds[i]
                ard += abs(pd - gds[i]) / gds[i]
            if gds[i] < 1:
                log_count += 1
            else:
                logrmse += (np.log(pd) - np.log(gds[i])) ** 2
            # threshold = 1.25 1.25**2 1.25**3
            if pd / gds[i] < 1.25 and gds[i] / pd < 1.25:
                the1 += 1
            if pd / gds[i] < 1.25 ** 2 and gds[i] / pd < 1.25 ** 2:
                the2 += 1
            if pd / gds[i] < 1.25 ** 3 and gds[i] / pd < 1.25 ** 3:
                the3 += 1
            count += 1
    print("count", ard, count)
    print("MAE:", mae / count)
    print("RMSE:", np.sqrt(rmse / count))
    print("Log RMSE:", np.sqrt(logrmse / (count - log_count)))
    print("ARD/AbsRel:", ard / (count - di_count))
    print("aqrel", aqrel / (count - di_count))
    print("Threshold", the1 / count, the2 / count, the3 / count)
    com_acc(pds, gds)
# pds = []
# gds = []
# train_01=sio.loadmat('E:\\pyproject\\AMDEN\\data\\mat\\apollo_train01_new.mat')
# for key in train_01.keys():
#     if not key in ['__header__', '__version__', '__globals__']:
#         for data in train_01[key]:
#             if len(data) == 4: # fc bbox pd_raw gd
#                 gds.append(data[3][0][0])
#                 pds.append(data[2][0][0])
# print('a')
# MAEs(pds, gds)

# kitti_memory = np.load('E:\\pyproject\\AMDEN\\data\\mat\\kitti_memory_10.npy', allow_pickle=True)
# sio.savemat('E:\\matlab project\\analysis_cvpr\\kitti_memory_10.mat', {'memory':kitti_memory})

kitti_memory_0323 = np.load("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_low.npy", allow_pickle=True)
kitti_memory_new = sio.loadmat('E:\\matlab project\\analysis_cvpr\\memory_new.mat')
for key in kitti_memory_new:
    if not key in ['__header__', '__version__', '__globals__']:
        data = kitti_memory_new[key]
        np.save("E:\\pyproject\\AMDEN\\data\\mat\\memories\\kitti_memory_concoct.npy", np.array(data))


print('a')