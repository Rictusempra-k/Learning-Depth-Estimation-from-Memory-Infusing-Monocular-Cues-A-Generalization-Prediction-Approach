from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import os

import cv2
import glob
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from lib.config import config as cfg
from lib.config.config import ms
from lib.utils.test import im_detect
#from nets.resnet_v1 import resnetv1
from lib.nets.vgg16 import vgg16
from lib.utils.timer import Timer
from lib.demo import show
import scipy.io as sio




def demo(sess, net, image_name):
    """Detect object classes in an image using pre-computed object proposals."""

    # Load the demo image
    # print("path", os.path.join(cfg.FLAGS.test_img, image_name))
    im = cv2.imread(image_name)
    cv2.imshow("im", im)
    # cv2.waitKey()
    # im = cv2.resize(im, (500, 375))
    # Detect all object classes and regress object bounds
    timer = Timer()
    timer.tic()
    scores, boxes, dis, fc = im_detect(sess, net, im)  # 21 cls  scores:(300, 21) boxes:(300, 84)
    timer.toc()
    print('Detection took {:.3f}s for {:d} object proposals'.format(timer.total_time, boxes.shape[0]))
    # Visualize detections for each class
    CONF_THRESH = 0.1
    NMS_THRESH = 0.1
    # print("fc", fc.shape)
    # print("boxes", boxes.shape)
    show.vis_detections(image_name, scores, boxes, dis, fc,  NMS_THRESH, CONF_THRESH)



def parse_args():
    """Parse input arguments."""
    parser = argparse.ArgumentParser(description='Tensorflow Faster R-CNN demo')
    parser.add_argument('--net', dest='demo_net', help='Network to use [vgg16 res101]',
                        choices=cfg.NETS.keys(), default='vgg16')
    parser.add_argument('--dataset', dest='dataset', help='Trained dataset [pascal_voc pascal_voc_0712]',
                        choices=cfg.DATASETS.keys(), default='pascal_voc_0712')
    args = parser.parse_args()

    return args


if __name__ == '__main__':
    args = parse_args()

    data_name = "city"

    # model path
    demonet = args.demo_net
    dataset = args.dataset
    tfmodel = os.path.join('/media/dyz/Data/weight/Faster_RCNN/vgg16/kitti_2012_trainval_with_dis/', 'default', cfg.NETS[demonet][0])
    print(tfmodel)
    # if not os.path.isfile(tfmodel + '.meta'):
    #     print(tfmodel)
    #     raise IOError(('{:s} not found.\nDid you download the proper networks from '
    #                    'our server and place them properly?').format(tfmodel + '.meta'))

    # set config
    tfconfig = tf.ConfigProto(allow_soft_placement=True)
    tfconfig.gpu_options.allow_growth = True

    # init session
    sess = tf.Session(config=tfconfig)
    # load network
    if demonet == 'vgg16':
        net = vgg16(batch_size=1)
    # elif demonet == 'res101':
        # net = resnetv1(batch_size=1, num_layers=101)
    else:
        raise NotImplementedError
    net.create_architecture(sess, "TEST", 10,
                            tag='default', anchor_scales=[8, 16, 32])
    saver = tf.train.Saver()
    # saver.restore(sess, tfmodel)

    print('Loaded network {:s}'.format(tfmodel))

    # ---------------------------------------------------------------------
    # KITTI
    # test_list = open('/media/dyz/Data/KITTI2012/ImageSets/Main/val.txt').readlines()
    # kitti_list = [os.path.join(cfg.FLAGS.kitti_png, test_name[:-1] + ".png") for test_name in test_list]

    # cityscapes
    citylist = []
    for file in os.listdir(cfg.FLAGS.city_path):
        for name in os.listdir(os.path.join(cfg.FLAGS.city_path, file)):
            file_name = os.path.join(cfg.FLAGS.city_path, file, name)
            print("city name", file_name)
            citylist.append(file_name)

    for im_name in citylist:
        print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        print('Demo for /{}'.format(im_name))
        demo(sess, net, im_name)
    sio.savemat("data/mat/city_train.mat", ms)

    # KITTI2015
    # for file in os.listdir(cfg.FLAGS.kitti2015_path):
    #     if (file == 'image_2') or (file == 'image_3'):
    #         for name in os.listdir(os.path.join(cfg.FLAGS.kitti2015_path, file)):
    #             if name.split('_')[-1] == '10.png':
    #                 im_name = os.path.join(cfg.FLAGS.kitti2015_path, file, name)
    #                 print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
    #                 print('Demo for /{}'.format(im_name))
    #                 demo(sess, net, im_name)
    # sio.savemat("data/mat/kitti2015_train.mat", ms)

    # def sorted_list(list_1, list_2):
    #     plt_z = []
    #     for kk in range(len(list_1)):
    #         plt_z.append((list_1[kk], kk))
    #
    #     sorted_z = sorted(plt_z, key=lambda s: s[0])
    #
    #     plt_pz = []
    #     plt_rz = []
    #     for jj in range(len(plt_z)):
    #         plt_pz.append(list_2[sorted_z[jj][1]])
    #         plt_rz.append(sorted_z[jj][0])
    #
    #     return plt_pz, plt_rz
