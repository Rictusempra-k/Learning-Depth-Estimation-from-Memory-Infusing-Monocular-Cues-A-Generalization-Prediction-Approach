import urllib.request
import zipfile
import sys
import os
from _init_ import DATA_URLS
from _init_ import FLAGS


def download_and_uncompress_zip(zip_url, dataset_dir):
    """Downloads the `zip_url` and uncompresses it locally.
     From: https://github.com/tensorflow/models/blob/master/slim/datasets/dataset_utils.py

    Args:
    zip_url: The URL of a zip file.
    dataset_dir: The directory where the temporary files are stored.
    """
    filename = zip_url.split('/')[-1]  # 读取文件名
    filepath = os.path.join(dataset_dir, filename)

    # Download
    def _progress(count, block_size, total_size):  # 显示下载进程
        # sys.stdout.write这个方法调用的是 ，file 对象中的write方法 ，把字符写到标准输出中，看起来跟print 差不多。
        sys.stdout.write('\r>> Downloading %s %.1f%%' % (
            filename, float(count * block_size) / float(total_size) * 100.0))
        sys.stdout.flush()

    urllib.request.urlretrieve(zip_url, filepath, _progress)

    # extractall
    with zipfile.ZipFile(filepath) as f:
        print('Extracting ', filepath)
        f.extractall(dataset_dir)  # Extract 解压
        print('Successfully extracted')

if __name__ == '__main__':
    # run
    for zip_url in DATA_URLS:
        download_and_uncompress_zip(zip_url, FLAGS.dataset_dir)
