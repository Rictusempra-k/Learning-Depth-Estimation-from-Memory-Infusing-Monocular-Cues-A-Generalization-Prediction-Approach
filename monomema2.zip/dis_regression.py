from lib.datasets.kitti import kitti
import tensorflow as tf
from lib.config.config import FLAGS, KITTI_classes
import numpy as np
import matplotlib.pyplot as plt

kitti = kitti()

checkpoint_dir = 'data\\ckpt\\'

x = tf.placeholder(tf.float32, [12])
y = tf.placeholder(tf.float32, [1])

weight = tf.get_variable(name='weight', shape=[12],
                            initializer=tf.random_normal_initializer(mean=0, stddev=1),
                            regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))

biases = tf.get_variable(name='biases', shape=[1],
                         initializer=tf.zeros_initializer(),
                         regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))


def reg(x_, weights, bias):
    dis = tf.reduce_sum(tf.multiply(weights, x_)) + bias
    return dis

D = reg(x, weight, biases)

loss = tf.reduce_sum(tf.square(D - y))
train_step = tf.train.GradientDescentOptimizer(FLAGS.learning_rate).minimize(loss)

saver = tf.train.Saver()

config = tf.ConfigProto(allow_soft_placement=True)
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.7)
# 开始不会给tensorflow全部gpu资源 而是按需增加
config.gpu_options.allow_growth = True
with tf.Session(config=config) as sess:
    sess.run(tf.global_variables_initializer())
    kk = 0
    loss_list = []
    while kk < 1000000:
        if kk == 20000:
            FLAGS.learning_rate /= 10
        if kk == 100000:
            FLAGS.learning_rate /= 10
        if kk == 500000:
            FLAGS.learning_rate /= 10
        if kk == 800000:
            FLAGS.learning_rate /= 10
        im, index, x_left, y_top, x_right, y_bottom, dis_x, dis_y, dis_z = kitti()
        for ii in range(len(im)):
            if index[ii] == 8:
                print(KITTI_classes[index[ii]])
                continue
            else:
                x_c = (x_left[ii] + x_right[ii])/2/1000
                y_c = y_bottom[ii]/1000
                data = np.array([x_c, x_c**2, x_c**3, x_c**4, np.sqrt(x_c), y_c, y_c**2, y_c**3, y_c**4, np.sqrt(y_c), x_c*y_c, x_c*(y_c**2)])
                dis_r = np.array([np.sqrt(dis_x[ii]**2 + dis_y[ii]**2 + dis_z[ii]**2)/50])
                loss_, _, D_ = sess.run([loss, train_step, D], feed_dict={x: data, y: dis_r})
                if kk % 1000 == 0:
                    if kk % 100000 == 0:
                        saver.save(sess, checkpoint_dir + 'model.ckpt', global_step=kk)
                    loss_list.append(loss_)
                    print("real_dis:", dis_r[0]*50, "  pre_dis:", D_[0]*50, "  Error: %.4f%%" % (abs(D_[0]-dis_r[0])/dis_r[0]*100), "  loss", loss_)
        kk += 1

    plt.plot(np.arange(len(loss_list)), loss_list, "cs")
    plt.show()

# 计算KittiRGB三通道图像均值
# path = "F:\\ipython\\code\\Mask_RCNN\\Mask_R-CNN\\data\\KitDevkit2012\\KITTI2012\\PNGImages\\"
# r = []
# g = []
# b = []
# for file in os.listdir(path):
#     im = cv2.imread(path + file)
#     im_r = np.sum(np.sum(im[:, :, 0]))
#     im_r = im_r/(im.shape[0] * im.shape[1])
#     im_g = np.sum(np.sum(im[:, :, 1])) / im.shape[0] / im.shape[1]
#     im_b = np.sum(np.sum(im[:, :, 2])) / im.shape[0] / im.shape[1]
#     r.append(im_r), g.append(im_g), b.append(im_b)
#
# le = len(r)
# print(sum(r)/le, sum(g)/le, sum(b)/le)