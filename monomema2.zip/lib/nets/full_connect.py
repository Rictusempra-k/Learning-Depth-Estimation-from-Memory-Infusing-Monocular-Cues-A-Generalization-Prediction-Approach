import numpy as np
import tensorflow as tf
import tensorflow.contrib.slim as slim
import math

import scipy.io as sio
# _kitti_test = []
# kitti_test = sio.loadmat("E:/pyproject/AMDEN/data/mat/kitti_test.mat") # kitti test
#
# for key in kitti_test.keys():
#     if 10 >= len(kitti_test[key]) >= 1:
#         for data in kitti_test[key]:
#             if len(data) == 4: # fc bbox pd_raw gd name
#                 gd = [data[3][0][0], data[3][0][2]]
#                 _kitti_test.append([data[0][0], data[1][0],
#                                data[2][0], gd, key])
# np.save("E:\\pyproject\\AMDEN\\data\\mat\\kitti_test.npy", np.array(_kitti_test))
# kitti_test = np.load("E:\\pyproject\\AMDEN\\data\\mat\\kitti_test.npy", allow_pickle=True)

def com_acc(pre, rea):
    '''
    pre [[x, y, z], [x, y, z], ...]
    '''
    count = 0
    acc_list = [0 for _ in range(6)]
    for i, data in enumerate(pre):
        pd = data
        gd = rea[i]
        count += 1
        for i, zeta in enumerate([0.05, 0.1, 0.15, 0.2, 0.25, 0.3]):
            if abs(gd - pd) / gd < zeta:
                acc_list[i] += 1
    acc = [a / count for a in acc_list]
    print("Acc:", acc)


def MAEs(pds, gds):
    # mae = 0  # abs rel
    # aqrel = 0
    # rmse = 0
    # logrmse = 0
    # ard = 0
    # count = 0
    # di_count = 0
    # log_count = 0
    # the1, the2, the3 = 0, 0, 0
    # for i, pd in enumerate(pds):
    #     if gds[i] < 25:
    #         if gds[i] == 0:
    #             gds[i] += 10e-8
    #         mae += abs(pd - gds[i])
    #         rmse += (pd - gds[i]) ** 2
    #
    #         if gds[i] <= 0.1:
    #             di_count += 1
    #         else:
    #             aqrel += abs(pd - gds[i]) ** 2 / gds[i]
    #             ard += abs(pd - gds[i]) / gds[i]
    #         if gds[i] < 1 or pd < 0: #pd不能为负
    #             log_count += 1
    #         else:
    #             logrmse += (np.log(pd) - np.log(gds[i])) ** 2
    #         # threshold = 1.25 1.25**2 1.25**3
    #         if pd / gds[i] < 1.25 and gds[i] / pd < 1.25:
    #             the1 += 1
    #         if pd / gds[i] < 1.25 ** 2 and gds[i] / pd < 1.25 ** 2:
    #             the2 += 1
    #         if pd / gds[i] < 1.25 ** 3 and gds[i] / pd < 1.25 ** 3:
    #             the3 += 1
    #         count += 1
    # print("count", ard, count)
    # print("MAE:", mae / count)
    # print("RMSE:", np.sqrt(rmse / count))
    # print("Log RMSE:", np.sqrt(logrmse / (count - log_count)))
    # print("ARD/AbsRel:", ard / (count - di_count))
    # print("aqrel", aqrel / (count - di_count))
    # print("Threshold", the1 / count, the2 / count, the3 / count)
    com_acc(pds, gds)

# pds = []
# for i in range(len(kitti_test)):
#     pds.append(kitti_test[:, 2][i][2])
# gds = []
# for i in range(len(kitti_test)):
#     gds.append(kitti_test[:, 3][i][1])
#
# MAEs(list(pds), list(gds))

# x = tf.placeholder(tf.float32, shape=[None, 4096])
# y = tf.placeholder(tf.float32, shape=[None, 1])
# layer_1 = slim.fully_connected(x, 512,
#         weights_initializer=tf.truncated_normal_initializer(mean=0.0, stddev=0.01),
#         trainable=True, activation_fn=None)
# layer_2 = slim.fully_connected(layer_1, 256,
#         weights_initializer=tf.truncated_normal_initializer(mean=0.0, stddev=0.01),
#         trainable=True, activation_fn=None)
# dis = slim.fully_connected(layer_2, 1,
#         weights_initializer=tf.truncated_normal_initializer(mean=0.0, stddev=0.01),
#         trainable=True, activation_fn=None)
#
# loss = tf.reduce_sum(tf.norm(tf.abs(y - dis), axis=1))
# extra_update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
# optim = tf.train.AdamOptimizer(1e-3)
# grads = optim.compute_gradients(loss)
# train_step = optim.apply_gradients(grads)
# config = tf.ConfigProto(allow_soft_placement=True)
# config.gpu_options.allocator_type = 'BFC'
# sess = tf.Session(config=config)
# variables = tf.global_variables()
# sess.run(tf.variables_initializer(variables, name='init'))
#
# kitti_train_npy = np.load("E:/pyproject/AMDEN/data/mat/kitti_train_new.npy", allow_pickle=True)
# kitti_test_npy = np.load("E:/pyproject/AMDEN/data/mat/kitti_test_new.npy", allow_pickle=True)
# city_val_npy = np.load("E:/pyproject/amden_new/data/mat/city_val_new.npy", allow_pickle=True)
# city_train_npy = np.load("E:/pyproject/amden_new/data/mat/city_train_new.npy", allow_pickle=True)
# apollo_test = np.load("E:\\pyproject\\AMDEN\\data\\mat\\apollo_train01_new.mat", allow_pickle=True)
# batch_size = 50
# test_size = len(kitti_test_npy)
# train_size = len(kitti_train_npy)
# city_size = len(city_val_npy)
# apollo_size = len(apollo_test_npy)
# train_size_city = len(city_train_npy)-1
#
# for j in range(100000):
#     train_x = np.zeros((batch_size, 4096))
#     train_y = np.zeros((batch_size, 1))
#     test_x = np.zeros((test_size, 4096))
#     test_y = np.zeros((test_size, 1))
#     city_x = np.zeros((city_size, 4096))
#     city_y = np.zeros((city_size, 1))
#     apollo_x = np.zeros((apollo_size, 4096))
#     apollo_y = np.zeros((apollo_size, 1))
#     for i in range(batch_size):
#         number = (batch_size*j+i) % train_size
#         # number = (batch_size*j+i) % train_size_city
#         train_x[i, :] = kitti_train_npy[number, 0]
#         train_y[i, 0] = kitti_train_npy[number, 3][1]
#         # train_x[i, :] = city_train_npy[number, 0]
#         # train_y[i, 0] = city_train_npy[number, 3]
#     for i in range(test_size):
#         test_x[i, :] = kitti_test_npy[i, 0]
#         test_y[i, 0] = kitti_test_npy[i, 3][1]
#     # for i in range(city_size):
#     #     city_x[i, :] = city_val_npy[i, 0]
#     #     city_y[i, 0] = city_val_npy[i, 3]
#     for i in range(apollo_size):
#         apollo_x[i, :] = apollo_test_npy[i, 0]
#         apollo_y[i, 0] = apollo_test_npy[i, 3]
#     sess.run(train_step, feed_dict={x: train_x, y: train_y})
#     dis_pre = sess.run(dis, feed_dict={x: test_x, y: test_y})
#     # dis_pre_city = sess.run(dis, feed_dict={x: city_x, y: city_y})
#     dis_pre_apollo = sess.run(dis, feed_dict={x: apollo_x, y: apollo_y})
#     if j % 100 == 0:
#         print('epoch{}'.format(j))
#         MAEs(test_y, dis_pre)
#         # print('city_result:')
#         # MAEs(city_y, dis_pre_city)
#         print('apollo_result:')
#         MAEs(apollo_y, dis_pre_apollo)
# print('cool')

apollo_mat = sio.loadmat("E:\\pyproject\\AMDEN\\data\\mat\\apollo_train01_new.mat")
for key in apollo_mat:
    if not key in ['__header__', '__version__', '__globals__']:
        for data in apollo_mat[key]:
            if len(data) == 4: # fc bbox pd_raw gd
