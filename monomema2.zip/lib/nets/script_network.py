from __future__ import division

import tensorflow.contrib.rnn as rnn
import tensorflow.contrib.slim as slim
# from matplotlib.font_manager import FontProperties
# import matplotlib.pyplot as plt
import tensorflow as tf
import scipy.io as sio
import numpy as np
import matplotlib
import random
# import math
# import copy
import cv2
import os


from novamind.ops.text_ops import list_save, text_read

## kitti
kitti_train = sio.loadmat("E:/pyproject/AMDEN/data/mat/kitti_train.mat")  # kitti all train data
kitti_test = sio.loadmat("E:/pyproject/AMDEN/data/mat/kitti_test.mat") # kitti test
kitti_val = sio.loadmat("E:/pyproject/AMDEN/data/mat/kitti_val.mat") # kitti val
kitti_memory_0323 = np.load("E:/pyproject/AMDEN/data/mat/kitti_memory_0323.npy",allow_pickle=True)
kitti_train_npy = np.load("E:/pyproject/AMDEN/data/mat/kitti_train.npy",allow_pickle=True)




class LSTM:
    def __init__(self, Seg, hidden_size, batch_size):
        self.Seg = Seg
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.reuse = False

    def call_lstm(self, x, init_state):  # x: [batch_size, time_step, input_size]

        init_state = slim.fully_connected(init_state, self.lstm_out,
                                   weights_initializer=tf.truncated_normal_initializer(mean=0.0, stddev=0.01),
                                   trainable=True, activation_fn=None, scope='F')

        data = tf.split(x, self.Seg, 1)
        lstm_cell = rnn.BasicLSTMCell(num_units=self.hidden_size, reuse=self.reuse)
        outputs = list()
        (c_pre, h_pre) = lstm_cell.zero_state(self.batch_size, dtype=tf.float32)
        state = (rnn.LSTMStateTuple(c_pre, init_state))
        # state = init_state
        with tf.variable_scope('Attention_Model'):
            for timestep in range(self.Seg):
                if timestep > 0:
                    tf.get_variable_scope().reuse_variables()
                inda = tf.squeeze(data[timestep])
                inda = tf.expand_dims(inda, 0)
                # print("inda", inda)
                # help(lstm_cell)
                (cell_output, state) = lstm_cell(inda, state)   #zjk疑问： state没有得到传递啊
                # print("cell_output", cell_output)
                outputs.append(cell_output)
        self.reuse = True
        h_state = outputs[-1]
        self.variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="lstm")
        return h_state


class Adaptive_Network(LSTM):
    def __init__(self):
        # init paraments
        self.iters = 5000000
        self.batch_size = 1
        self.count = 0
        self.memory_size = 100
        self.k = 10
        self.zeta_d = 0.1
        self.ada = {}
        self.lr = 0.00001
        self.lstm_out = 512
        self.threshold = 25
        self.scale = 1.5
        self.depth = 2  # kitti=2 city=1
        self.data_name = "kitti"  # "kitti" or "city"
        self.placeholder()
        self.memory_store = []

        # init children class
        super(Adaptive_Network, self).__init__(self.k, self.lstm_out, self.batch_size)

        self.train_data, self.test_data, self.memory_store = self.data_process()

    def placeholder(self):
        self.x = tf.placeholder(tf.float32, shape=[None, 4096])
        self.y = tf.placeholder(tf.float32, shape=[None, self.depth])
        self.mx = tf.placeholder(tf.float32, shape=[self.k, 4096])
        self.my = tf.placeholder(tf.float32, shape=[self.k, self.depth])
        self.is_training = True

    def build_network(self):
        emb_label = slim.fully_connected(self.my, self.lstm_out,
                                         weights_initializer=tf.truncated_normal_initializer(mean=0.0, stddev=0.01),
                                         trainable=self.is_training, activation_fn=None, scope='enbedded_label')

        # neighbor embedding concat embedded label
        concat_vector = tf.concat([self.mx, emb_label], 1)

        memory_state = slim.fully_connected(concat_vector, self.lstm_out,
                                            weights_initializer=tf.truncated_normal_initializer(mean=0.0, stddev=0.01),
                                            trainable=self.is_training, activation_fn=None, scope='concat_vector')

        memory_state = tf.expand_dims(memory_state, 0)

        # lstm zjk有问题
        out_state = self.call_lstm(memory_state, self.x)

        # logits linear layers
        dis = slim.fully_connected(out_state, self.depth,
                                   weights_initializer=tf.truncated_normal_initializer(mean=0.0, stddev=0.01),
                                   trainable=self.is_training, activation_fn=None, scope='out')

        self.ada["dis"] = dis

    def loss(self):
        pre_dis = self.ada["dis"]
        loss = tf.reduce_sum(tf.norm(tf.abs(pre_dis - self.y), axis=1))

        extra_update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        optim = tf.train.AdamOptimizer(self.lr)
        grads = optim.compute_gradients(loss)
        train_step = optim.apply_gradients(grads)

        self.ada["ext"] = extra_update_ops
        self.ada["train_step"] = train_step
        self.ada["loss"] = loss

    def run(self):
        saver = tf.train.Saver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.allocator_type = 'BFC'
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.8)

        config.gpu_options.allow_growth = True
        sess = tf.Session(config=config)
        # best kitti: 430000: 0.773
        sess.run(tf.global_variables_initializer())
        self.run_train(sess, saver)
        return pre, rea

    def run_train(self, sess, saver):
        # train
        acc_list = []
        for kk in range(180001, self.iters + 1):
            queary_x, queary_y = self.call_data()
            # find neighbor
            neighbor_vector, neighbor_label = self.KNN(self.memory_store, queary_x, self.k)
            self.is_training = True
            ada = sess.run(self.ada, feed_dict={self.x: queary_x, self.y: queary_y,
                                                self.mx: neighbor_vector, self.my: neighbor_label
                                                })

            if (kk % 20 == 0):
                # acc, _, _ = self.run_test(sess)
                print('\n step {}:loss{}'.format(kk-180000, ada['loss']))

            if (kk % 10 == 0) and (kk < 200000):
                self.update(ada["dis"], queary_y, queary_x)

            if kk % 1000 == 0:
                if kk < 5001:
                    self.lr = 0.0001
                elif 5000 < kk < 100001:
                    self.lr = 0.001
                elif 100000 < kk < 300001:
                    self.lr = 0.00005
                elif 300000 < kk < 400000:
                    self.lr = 0.00001
                else:
                    self.lr = 0.000001

                list_save(acc_list, "data/document/avden_acc_city_180000.txt")
                print(kk, "Ground Depth:", queary_y[0], "pre depth:", ada["dis"][0], "loss:", ada["loss"])
                print("==" * 80)

            if kk % 2000 == 0:
                saver.save(sess, "data/amden_ckpt/city/avden_" + str(kk) + ".ckpt")
                np.save("data/mat/city_memory_180000.npy", np.array(self.memory_store))


    def update(self, pd, gd, que_x):
        # print("pd", pd[0], gd[0])
        ard = abs(self.norm(pd[0]) - self.norm(gd[0]))/self.norm(gd[0])
        self.memory_store.append([que_x, gd, ard])
        # print("ard", ard)

        ard_list = [a[2] for a in self.memory_store]
        # print("ard_list", ard_list)
        ard_sort = self.arg_sort(ard_list, self.memory_size, True)
        # print("ard_sort", ard_sort)
        # input()

        new_memory = []

        for i, ards in enumerate(ard_sort):
            new_memory.append(self.memory_store[ards[0]])

        self.memory_store = new_memory

    def norm(self, xyz):
        return np.sqrt(sum([x**2 for x in xyz]))

    def arg_sort(self, raw, n, flags=False):
        '''
        @raw 一维列表
        @n 要返回n个最大值索引
        @flags 默认False求最小值 True返回索引最大值
        根据列表返回列表的前n个最大值的索引位置
        '''
        copy_raw = raw[::]
        copy_raw = [[index, node]for index, node in enumerate(copy_raw)]
        copy_raw.sort(key=lambda f:f[1], reverse=flags)
        return [num for num in copy_raw[:n]]

    def run_test(self, sess):
        queary_test = self.call_test()  # city_depth_label
        count = 0
        acc = 0
        pre_dep = []
        rea_dep = []
        self.is_training = False
        while True:
            try:
                [queary_x_test, queary_y_test, bbox, kiname] = next(queary_test)
                # print("name", kiname, queary_y_test)

                # find neighbor
                neighbor_vector, neighbor_label = self.KNN(self.memory_store, queary_x_test, self.k)
                dis = sess.run(self.ada["dis"], feed_dict={self.x: queary_x_test,
                                                           self.mx: neighbor_vector, self.my: neighbor_label
                                                           })
                if self.data_name == "kitti":
                    pd = self.norm(dis[0])
                    gd = self.norm(queary_y_test[0])  ## kitti
                    # gd = queary_y_test[0][0]  ## city
                else:
                    pd = dis[0][0]
                    gd = queary_y_test[0][0]

                pre_dep.append(pd)
                rea_dep.append(gd)
                # print("pd:", pd, "gd", gd)
                if abs(gd - pd) / gd < self.zeta_d:
                    acc += 1

                count += 1

            except StopIteration:
                break

        return acc / count, pre_dep, rea_dep

    def data_process(self):
        _kitti_train = []
        _kitti_test = []

        _kitti_train = kitti_train_npy.tolist()

        _kitti_memory = kitti_memory_0323.tolist()

        # kitti test
        for key in kitti_test.keys():
            if 10 >= len(kitti_test[key]) >= 1:
                for data in kitti_test[key]:
                    if len(data) == 4:  # fc bbox pd_raw gd name
                        gd = [data[3][0][0], data[3][0][2]]
                        _kitti_test.append([data[0][0], data[1][0],
                                            data[2][0], gd, key])

        return _kitti_train, _kitti_test, _kitti_memory

    def call_data(self):
        queary_x = np.zeros((self.batch_size, 4096))
        queary_y = np.zeros((self.batch_size, self.depth))
        if (self.count + 1) * self.batch_size >= len(self.train_data):
            random.shuffle(self.train_data)
            self.count = 0
        for i, data in enumerate(self.train_data[self.count * self.batch_size:(self.count + 1) * self.batch_size]):
            queary_x[i, :] = data[0]
            queary_y[i, :] = data[3]
        self.count += 1
        return queary_x, queary_y

    def call_test(self):
        queary_test_list = []
        city_depth_label = []
        for i, data in enumerate(self.test_data):
            queary_x_test = np.zeros((self.batch_size, 4096))  # 初始化一定要放到迭代里面，否则后面append都是同一个对象！
            queary_y_test = np.zeros((self.batch_size, self.depth))  # 初始化一定要放到迭代里面，否则后面append都是同一个对象！
            bbox = np.zeros((self.batch_size, 4))
            queary_x_test[0, :] = data[0]
            queary_y_test[0, :] = data[3]
            bbox = data[1]
            # city_depth_label.append(data[2])
            queary_test_list.append([queary_x_test, queary_y_test, bbox, data[4]])
        return iter(queary_test_list)  # , iter(city_depth_label)

    def KNN(self, memory_store, queays, TopK):
        '''
        memory_store:  memory_size*[[4096 dim vector], [1 dim dis]]
        queay: queay list [None, 4096]
        TopK: top-k
        '''
        queary = queays[0, :]
        # print(queary.shape)

        distance_list = []
        for xtr in memory_store:
            euclidean_distances = np.linalg.norm(xtr[0] - queary)
            # print("distance", euclidean_distances)
            distance_list.append(euclidean_distances)

        sort_dis = self.arg_sort(distance_list, TopK)  # 欧式距离最小的
        # print("sort_dis", sort_dis)

        memory_x = np.zeros((self.k, 4096))
        memory_y = np.zeros((self.k, self.depth))
        for i, res in enumerate(sort_dis):
            memory_x[i, :] = memory_store[res[0]][0]
            memory_y[i, :] = memory_store[res[0]][1]

        return memory_x, memory_y


if __name__ == '__main__':
    AN = Adaptive_Network()
    AN.build_network()
    AN.loss()
    pre, rea = AN.run()
    print("real", rea)
    print("pre", pre)
    # list_save(rea, "data/real.txt")
    # list_save(pre, "data/pre.txt")
    # AN.draw(pre, rea)

    # ci = CITY()
    # ci.load()

# ------------------------------------------------------------------------------
