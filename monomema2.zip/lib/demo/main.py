from __future__ import division
from lib.demo.box_reg import bbox_regression, all_anchors
from read_KITTI import read_kitti
from lib.config.config import RGB_list, FLAGS
from lib.demo.resnet import ResNet
from lib.demo.Iou import get_label
from lib.demo.RPN import RPN
import tensorflow as tf
from lib.demo.nms import nms
from lib.demo.ml import loss_function
import cv2

kitti = read_kitti()
cnn = ResNet()
rpn = RPN()
box_regression = bbox_regression()


im_in = tf.placeholder(tf.float32, [1, FLAGS.input_image[1], FLAGS.input_image[0], FLAGS.input_image[2]])  # (1, 600, 1000, 3)
cls_ = tf.placeholder(tf.float32, [512, 2])  # label
box_ = tf.placeholder(tf.float32, [2000, 4])

x_left_in = tf.placeholder(dtype=tf.int32, shape=[None, ])

y = tf.placeholder(tf.float32, [None, FLAGS.classes_numbers])

fc_out = cnn(im_in, scope='resnet')

cls = rpn.cls(fc_out)  # (?, 37, 62, 18)  所有的cls
box = rpn.bbox(fc_out)  # (?, 37, 62, 36)  A
box_all_anchors = all_anchors(box_regression, box)  # (1, 37, 62, 4, 9)  所有的box  G

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    for kk in range(1000):
        im, index, x_left, y_top, x_right, y_bottom, dis_x, dis_y, dis_z = kitti()
        box_all_anchors_np, cls_np = sess.run([box_all_anchors, cls], feed_dict={im_in: im})

        print(box_all_anchors_np)
        cls_label = get_label(box_all_anchors_np, index, x_left, y_top, x_right, y_bottom)  # [1, 37, 62, 2, 9]
        cls_sorted, box_sort, fg_label, cls_tf_sorted, box_tf_sorted = nms(cls_np, box_all_anchors_np, cls_label, cls, box_all_anchors)  # cls:[512, 2]  box:[2000, 4]
        loss = loss_function(cls_tf_sorted,  cls_, box_tf_sorted, (x_left, y_top, x_right, y_bottom))
        loss_ = sess.run(loss, feed_dict={cls_: fg_label, im_in: im})
        print(loss)
    # print(im.shape)
    # print(index, x_left, y_top, x_right, y_bottom, dis_x, dis_y, dis_z)
    # im = cv2.rectangle(im, (int(x_left[0]), int(y_top[0])),
    #                    (int(x_right[0]), int(y_bottom[0])), color=RGB_list[0],
    #                    thickness=2)
    # cv2.imshow('t', im[0, :, :, :])
    # cv2.waitKey()

