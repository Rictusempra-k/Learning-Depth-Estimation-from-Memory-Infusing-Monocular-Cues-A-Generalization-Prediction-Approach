from DeepLearning.deep_tensorflow import *
from lib.demo.ml import create_variables
from lib.config.config import FLAGS
import tensorflow as tf


class RPN:
    def __init__(self):
        self.batch_size = FLAGS.batch_size
        self.cls_reuse = False
        self.box_reuse = False

    def cls(self, feature, scope='cls'):
        with tf.variable_scope(scope, reuse=self.cls_reuse) as scope_name:
            if self.cls_reuse:
                scope_name.reuse_variables()
            weight_cls = create_variables(name='weight_cls', shape=[1, 1, 512, FLAGS.cls_depth])
            biases_cls = create_variables(name='biases_cls', shape=[FLAGS.cls_depth], initializer=tf.zeros_initializer())
            conv2d_cls = tf.nn.conv2d(feature, weight_cls, strides=[1, 1, 1, 1], padding='SAME') + biases_cls
            conv_BN_cls = Batch_Normalization(conv2d_cls, FLAGS.cls_depth)
            conv_cls = tf.nn.relu(conv_BN_cls)
            print(conv_cls)
        # reshape: from (?, 37, 62, 18) to (?, 37, 62, 9, 2)
        cls_reshape = tf.reshape(conv_cls, [1, 37, 62, 9, 2])  # 方便下一步softmax，因为softmax只是二分类出bg/fg
        cls_softmax = tf.nn.softmax(cls_reshape)
        cls_reshape_back = tf.reshape(cls_softmax, [1, 37, 62, 18])  # reshape回原来形状
        self.cls_reuse = True
        return cls_reshape_back

    def bbox(self, feature, scope='bbox'):
        with tf.variable_scope(scope, reuse=self.box_reuse) as scope_name:
            if self.box_reuse:
                scope_name.reuse_variables()
            weight_box = create_variables(name='weight_box', shape=[1, 1, 512, FLAGS.bbox_depth])
            biases_box = create_variables(name='biases_box', shape=[FLAGS.bbox_depth], initializer=tf.zeros_initializer())
            conv2d_box = tf.nn.conv2d(feature, weight_box, strides=[1, 1, 1, 1], padding='SAME') + biases_box
            conv_BN_box = Batch_Normalization(conv2d_box, FLAGS.bbox_depth)
            conv_box = tf.nn.relu(conv_BN_box)
            print(conv_box)
        conv_box = tf.reshape(conv_box, (1, 37, 62, 4, 9))
        self.box_reuse = True
        return conv_box
