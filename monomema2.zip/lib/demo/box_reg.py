from generate_anchors import generate_anchors
from lib.config import config as cfg

import tensorflow as tf
import numpy as np

anchors_ = generate_anchors()  # (9, 2)
# anchors_ = np.stack((anchors_, anchors_), 0)
# print(anchors_.shape)


def bbox_regression():
    feature_size = [37, 62]
    ratio_x, ratio_y = cfg.FLAGS.input_image[0]/feature_size[0], cfg.FLAGS.input_image[1]/feature_size[1]  # 从特征图的box映射回输入图片的box
    box_np = np.ones([37, 62, 2])
    box_np[:, :, 0] = np.reshape(np.arange(0, 37), (37, 1)) * np.ones((1, 62)) * ratio_x
    box_np[:, :, 1] = np.ones((37, 1)) * np.reshape(np.arange(0, 62), (1, 62)) * ratio_y
    return box_np  # [37, 62, 2]（anchors中心)  [:,:, 0] :x [:,:, 1] :y


def all_anchors(box, d_box):  # d_box(?, 37, 62, 4, 9)  4*9 = 36  4按照dx dy dw dh存储
    box = tf.convert_to_tensor(box, dtype=tf.float32)  # [37, 62, 2]
    anchors = tf.convert_to_tensor(anchors_, dtype=tf.float32)
    anchors = tf.concat([anchors, anchors], 1)  # 9, 4
    d_box_exp = tf.exp(d_box[:, :, :, 2:4, :])
    d_bbox = tf.concat([d_box[:, :, :, :2, :], d_box_exp], 3)
    zeros_box = tf.zeros((37, 62, 2, 9))
    add_box = tf.expand_dims(tf.concat([tf.expand_dims(box, 3) * tf.ones((1, 9), dtype=tf.float32), zeros_box], 2), 0)
    G = d_bbox * tf.transpose(anchors) + add_box  # shape=(1, 37, 62, 4, 9)  Gx Gy Gw Gh
    # for ii in range(37):  # 37
    #     print(ii)
    #     for jj in range(62):  # 62
    #         print(anchors[:, 0] * d_box[0, ii, jj, 0, :])
    #         G[0, ii, jj, :, :] = tf.transpose(anchors) * d_bbox[0, ii, jj, :, :]
    #         G[0, ii, jj, 0, :] = anchors[:, 0] * d_bbox[0, ii, jj, 0, :] + box[ii, jj, 0]*tf.ones(9)
    #         G[0, ii, jj, 1, :] = anchors[:, 1] * d_bbox[0, ii, jj, 1, :] + box[ii, jj, 1]*tf.ones(9)  # A_h*d_y + A_y
    #         G[0, ii, jj, 2, :] = anchors[:, 0] * d_bbox[0, ii, jj, 2, :]  # A_w*exp(dw)
    #         G[0, ii, jj, 3, :] = anchors[:, 1] * d_bbox[0, ii, jj, 3, :]  # A_w*exp(dw)
    #         # for kk in range(anchors.shape[0]):  # 9
    #         #     # A_x = box[ii, jj, 0]
    #         #     # A_y = box[ii, jj, 1]
    #         #     # A_w = anchors[kk][0]
    #         #     # A_h = anchors[kk][1]
    #         #     G[0, ii, jj, 0, kk] = anchors[kk, 0] * d_box[0, ii, jj, 0, kk] + box[ii, jj, 0]  # A_w*d_x + A_x
    #         #     G[0, ii, jj, 1, kk] = anchors[kk, 1] * d_box[0, ii, jj, 1, kk] + box[ii, jj, 1]  # A_h*d_y + A_y
    #         #     G[0, ii, jj, 2, kk] = anchors[kk, 0] * tf.exp(d_box[0, ii, jj, 2, kk])  # A_w*exp(dw)
    #         #     G[0, ii, jj, 3, kk] = anchors[kk, 1] * tf.exp(d_box[0, ii, jj, 3, kk])  # A_w*exp(dw)
    return G
