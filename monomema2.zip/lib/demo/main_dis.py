from __future__ import division
from lib.demo.box_reg import bbox_regression, all_anchors
from read_KITTI import read_kitti
from _init_ import RGB_list, FLAGS
from lib.demo.resnet import ResNet
from lib.demo.resnet_7 import ResNet7, train_loss
from lib.demo.Iou import get_label
from lib.demo.RPN import RPN
import tensorflow as tf
from lib.demo.nms import nms
from lib.demo.ml import loss_function
import cv2
from lib.demo.bbox_transform import box_transform
import numpy as np

x = tf.placeholder(tf.float32, [1, FLAGS.input_image[1], FLAGS.input_image[0], FLAGS.input_image[2]])  # (1, 600, 1000, 3)
y = tf.placeholder(tf.float32, [1, 8])
dis = tf.placeholder(tf.float32, [1, 3])
feature = tf.placeholder(tf.float32, [1, 7, 7, 512])

kitti = read_kitti()

cnn = ResNet()
cls_cnn = ResNet7()


fc_out = cnn(x, scope='resnet')  # shape=(1, 37, 62, 512)
print(fc_out)
fc1, fc2 = cls_cnn(feature, fc_out, scope='resnet7')
loss = train_loss(fc1, y, fc2, dis)

config = tf.ConfigProto(allow_soft_placement=True)
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.7)
# 开始不会给tensorflow全部gpu资源 而是按需增加
config.gpu_options.allow_growth = True
with tf.Session(config=config) as sess:
    sess.run(tf.global_variables_initializer())
    kk = 0
    while kk < 1000:
        kk += 1

        im, index,  x_left, y_top, x_right, y_bottom, dis_x, dis_y, dis_z = kitti()
        for ii in range(len(im)):
            if index == 9:
                continue
            else:
                x_target_left, x_target_right, y_target_top, y_target_bottom = box_transform(x_left[ii], y_top[ii], x_right[ii], y_bottom[ii])
                features = sess.run(fc_out, feed_dict={x: im})
                features = features[:, int(y_target_top):int(y_target_bottom), int(x_target_left):int(x_target_right), :]
                #print(features)
                feature_7 = np.resize(features, (1, 7, 7, 512))

                lab = np.zeros((1, 8))
                lab[0, index[ii]] = 1
                dis_ = np.zeros((1, 3))
                dis_[0, 0] = dis_x[ii]
                dis_[0, 1] = dis_y[ii]
                dis_[0, 2] = dis_z[ii]
                print(dis_)
                print(lab)
                fc1_, fc2_, loss_ = sess.run([fc1, fc2, loss], feed_dict={x:im,y:lab,dis:dis_, feature:feature_7})
                print("loss", loss_)
                print("fc", fc1_, fc2_)

