from resnet_class import ResNet_cls

