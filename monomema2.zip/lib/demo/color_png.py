import cv2
from lib.config import config as cfg
from lib.config.config import RGB_list, KITTI_classes, FLAGS
import PIL
from PIL import Image, ImageFont
import numpy as np
import os

font = ImageFont.load_default()

im = Image.new('RGBA', (230, 375), (255, 255, 255))
im.save("data\\png\\color.png")
im = cv2.imread('data\\png\\color.png')
rect_width, rect_height = 70, 10
margin = np.ceil(0.05 * rect_height)
draw_loc = int((375 - len(RGB_list)*30)/len(RGB_list))
for index in range(len(RGB_list)):
    im = cv2.rectangle(im, (10, draw_loc), (10 + rect_width, draw_loc + 30), color=RGB_list[index], thickness=-1)
    im = cv2.putText(im, KITTI_classes[index], (90, draw_loc + 20),
                     cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1, 5)
    draw_loc += 30 + int((375 - len(RGB_list)*30)/len(RGB_list))
cv2.imshow("color", im)
cv2.waitKey()
cv2.imwrite('data\\png\\color_.png', im)

for index_im, img_name in enumerate(os.listdir(FLAGS.KITTI_Image_Training_PATH)):
    # print(img_name, img_name.split('.'))
    f_line = open(os.path.join(FLAGS.KITTI_Image_Label_PATH, str(img_name.split('.')[0]) + ".txt")).readlines()
    im = cv2.imread(os.path.join(FLAGS.KITTI_Image_Training_PATH, img_name))
    for f in f_line:
        signal_obj = f.split(" ")
        print("-----------------", signal_obj)
        index = KITTI_classes.index(signal_obj[0])
        dis_x, dis_y, dis_z = float(signal_obj[11]), float(signal_obj[12]), float(signal_obj[13])
        print(dis_x, dis_y, dis_z)
        D = np.sqrt(dis_x**2 + dis_y**2 + dis_z**2)
        margin = np.ceil(0.05 * 80)
        # print(index, float(signal_obj[4]))
        im = cv2.rectangle(im, (int(float(signal_obj[4])), int(float(signal_obj[5]))),
                           (int(float(signal_obj[6])), int(float(signal_obj[7]))), color=RGB_list[index], thickness=5)
        # thickness=-1 :填充整个矩形
        im = cv2.rectangle(im, (int(float(signal_obj[4]) - 0.7 * margin), int(float(signal_obj[5]) - 10 * margin)),
                           (int(float(signal_obj[6]) + 0.7 * margin), int(float(signal_obj[5]))), color=RGB_list[index],
                           thickness=-1)
        im = cv2.putText(im, str(D), (int(float(signal_obj[4])), int(float(signal_obj[5]) - 6*margin)),
                         cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, 2)
        im = cv2.putText(im, KITTI_classes[index], (int(float(signal_obj[4])), int(float(signal_obj[5]) - margin)),
                         cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1, 2)
    img2 = cv2.imread('data\\png\\color_.png')
    # print(img2.shape)
    (h1, w1, _) = im.shape
    (h2, w2, _) = img2.shape
    img2 = cv2.resize(img2, (w2, h1))
    im2 = np.zeros((h1, w1 + w2, 3))
    im2[:, :w1, :] = im
    im2[:, w1:, :] = img2
    # print(img2.shape, im2.shape)
    # cv2.imwrite('data\\out\\test_' + str(index_im) + '.png', im2)
    cv2.imshow('KITTI', im2)
    cv2.waitKey()



