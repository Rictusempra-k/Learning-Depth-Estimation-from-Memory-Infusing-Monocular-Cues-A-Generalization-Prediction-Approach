from lib.config import config as cfg
import numpy as np
weight = np.loadtxt(cfg.FLAGS.dis_weight)


def reg(bbox):
    (x_left, y_top, x_right, y_bottom) = bbox  # # x_left, y_top, x_right, y_bottom
    x_c = (x_left + x_right)/2/1000
    y_c = y_bottom/1000
    img_dis = np.array([x_c, x_c**2, x_c**3, x_c**4, np.sqrt(x_c), y_c, y_c**2, y_c**3, y_c**4, np.sqrt(y_c), x_c*y_c, x_c*(y_c**2)])
    dis = sum(weight[:12]*img_dis) + weight[-1]
    return dis*50


