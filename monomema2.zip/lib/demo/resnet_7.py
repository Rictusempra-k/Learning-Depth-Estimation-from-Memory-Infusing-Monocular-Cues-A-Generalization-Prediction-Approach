from __future__ import division

from DeepLearning.deep_tensorflow import *
from lib.demo.ml import create_variables
from lib.config.config import FLAGS


def _decay():
    """L2 weight decay loss."""
    costs = []
    for var in tf.trainable_variables():
        print("------------", var)
        costs.append(tf.nn.l2_loss(var))
        # tf.summary.histogram(var.op.name, var)
    return tf.multiply(FLAGS.weight_decay, tf.add_n(costs))


def train_loss(prediction, labels,  fc2, dis, optimizer="Mom"):
    # demo1
    # prediction = tf.nn.softmax(prediction)
    # cross_entropy = -tf.reduce_sum(labels * tf.log(prediction))        # 求和
    # demo2
    cross_entropy = tf.nn.softmax_cross_entropy_with_logits(logits=prediction, labels=labels)
    cross_entropy_loss = tf.reduce_sum(cross_entropy)
    dis_loss = tf.reduce_sum(tf.square(fc2 - dis))
    weight_decay_loss = _decay()
    loss = cross_entropy_loss + weight_decay_loss + dis_loss
    if optimizer == "Mom":  # Momentum
        train_step = tf.train.MomentumOptimizer(FLAGS.learning_rate, 0.9).minimize(loss)
    elif optimizer == 'RMSProp':
        train_step = tf.train.RMSPropOptimizer(0.001, 0.9).minimize(loss)
    else:        # SGD
        train_step = tf.train.GradientDescentOptimizer(FLAGS.learning_rate).minimize(loss)

    # ----------------------------------------------------------------------------
    # correct_prediction = tf.equal(tf.argmax(prediction, 1), tf.argmax(labels, 1))
    # accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))
    # tf.summary.scalar("Loss_Function", loss)
    # tf.summary.scalar("acc", accuracy)
    return loss


def Residual_block(in_img, filters, down_sample, projection=False):
    input_depth = int(in_img.get_shape()[3])
    if down_sample:
        stride = 2
    else:
        stride = 1
    # if down_sample:
    #     filter_ = [1, 2, 2, 1]
    #     in_img = tf.nn.max_pool(in_img, ksize=filter_, strides=filter_, padding='SAME')

    with tf.variable_scope('conv1'):
        weight_1 = create_variables(name='weight_1', shape=[3, 3, input_depth, filters])
        biases_1 = create_variables(name='biases_1', shape=[filters], initializer=tf.zeros_initializer())
        conv1_ReLu = Conv_BN_Relu(in_img, weight_1, biases_1, filters, strides=stride)

    with tf.variable_scope('conv2'):
        weight_2 = create_variables(name='weight_2', shape=[3, 3, filters, filters])
        biases_2 = create_variables(name='biases_2', shape=[filters], initializer=tf.zeros_initializer())
        conv2_ReLu = Conv_BN_Relu(conv1_ReLu, weight_2, biases_2, filters, strides=1)

    if input_depth != filters:
        if projection:
            # Option B: Projection shortcut
            weight_3 = create_variables(name='weight_3', shape=[1, 1, input_depth, filters])
            biases_3 = create_variables(name='biases_3', shape=[filters], initializer=tf.zeros_initializer())
            input_layer = Conv_BN_Relu(in_img, weight_3, biases_3, filters, strides=stride)
        else:
            # Option A: Zero-padding
            if down_sample:
                in_img = ave_pool(in_img)
            input_layer = tf.pad(in_img, [[0, 0], [0, 0], [0, 0], [int((filters - input_depth)/2), filters - input_depth - int((filters - input_depth)/2)]])  # 维度是4维[batch_size, :, :, dim] 我么要pad dim的维度
    else:
        input_layer = in_img

    output = conv2_ReLu + input_layer
    output = tf.nn.relu(output)
    return output



"""
  resnet-cifar10
  in: [32, 32, 3]
  conv: [32， 32， 16]
  conv1 :[32, 32, 16*k]
  conv2: [16, 16, 32*k]
  conv3: [8, 8, 64*k]
  ave-pool : [8*8] pooling----[1*1]
  fc: [64*k, 10]
"""


class ResNet7:
    def __init__(self):
        self.img = None
        self.reuse = False
        self.learning_rate = FLAGS.learning_rate
        self.k = 1    # Original architecture
        self.filter = [16, 16*self.k, 32*self.k, 64*self.k]

    def __call__(self, img, fc_in, scope):
        self.img = img         # [224, 224, 3]
        with tf.variable_scope(scope, reuse=self.reuse) as scope_name:
            if self.reuse:
                scope_name.reuse_variables()
            # conv1
            with tf.variable_scope('conv_pre'):   # 32
                weight_1 = create_variables(name='weight', shape=[3, 3, 512, self.filter[0]])
                biases_1 = create_variables(name='biases', shape=[self.filter[0]], initializer=tf.zeros_initializer())
                conv1_ReLu = tf.nn.conv2d(self.img, weight_1, strides=[1, 1, 1, 1], padding='SAME') + biases_1
                conv1_BN = Batch_Normalization(conv1_ReLu, self.filter[0])
                conv1 = tf.nn.relu(conv1_BN)
            #conv1 = ave_pool(conv1, k_size=(2, 2))
            # conv2
            in_img = conv1
            for ii in range(1, 4):
                with tf.variable_scope('conv' + str(ii)):   # 64
                    for kk in range(4):
                        down_sample = False
                        with tf.variable_scope('con_' + str(kk)):
                            in_img = Residual_block(in_img, filters=self.filter[ii], down_sample=down_sample)
            # out = tf.nn.max_pool(in_img, ksize=(1, 2, 2, 1), strides=(1, 2, 2, 1), padding='VALID')  # shape=(?, 37, 62, 512)
            print("77777777777777777777777777777777777777777777777", in_img)
            out = in_img
            with tf.variable_scope('fc_in'):    # shape=(1, 37, 62, 512)
                fc_in = tf.nn.max_pool(fc_in, ksize=(1, 8, 8, 1), strides=(1, 4, 4, 1), padding='VALID')  # 1 8 14 512
                print(fc_in)
                mean, variance = tf.nn.moments(fc_in, axes=[0, 1, 2])
                beta = tf.get_variable('beta', 512, tf.float32,
                                       initializer=tf.constant_initializer(0.0, tf.float32))
                gamma = tf.get_variable('gamma', 512, tf.float32,
                                        initializer=tf.constant_initializer(1.0, tf.float32))
                bn_layer = tf.nn.batch_normalization(fc_in, mean, variance, beta, gamma, 0.0001)
                relu_layer = tf.nn.relu(bn_layer)
                print(relu_layer)
                relu_layer = tf.reshape(relu_layer, (1, 8 * 14 * 512))
                # global_pool = tf.reduce_mean(relu_layer, [1, 2])
                # # global_pool = ave_pool(relu_layer, k_size=(8, 8))
                print("global_pool", relu_layer)

                weight_fc = tf.get_variable('fc_weight', [8 * 14 * 512, 1000],
                                            initializer=tf.uniform_unit_scaling_initializer(factor=1.0),
                                            regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))
                biases_fc = tf.get_variable('fc_biases', [1000],
                                            initializer=tf.zeros_initializer(),
                                            regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))
                fc_in_out = tf.matmul(relu_layer, weight_fc) + biases_fc

                mean, variance = tf.nn.moments(fc_in_out, [0, 1])
                fc_in_out = tf.nn.batch_normalization(fc_in_out, mean, variance, 0, 1, 0.0001)
                print(fc_in_out)
            with tf.variable_scope('fc1'):
                mean, variance = tf.nn.moments(out, axes=[0, 1, 2])
                beta = tf.get_variable('beta', 64, tf.float32,
                                       initializer=tf.constant_initializer(0.0, tf.float32))
                gamma = tf.get_variable('gamma', 64, tf.float32,
                                        initializer=tf.constant_initializer(1.0, tf.float32))
                bn_layer = tf.nn.batch_normalization(out, mean, variance, beta, gamma, 0.0001)
                relu_layer = tf.nn.relu(bn_layer)
                global_pool = tf.reduce_mean(relu_layer, [1, 2])
                # # global_pool = ave_pool(relu_layer, k_size=(8, 8))
                print("global_pool", global_pool)
                #relu_layer = tf.reshape(global_pool, (1, 3*3*64))
                weight_fc = tf.get_variable('fc_weight', [64, 8], initializer=tf.uniform_unit_scaling_initializer(factor=1.0), regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))
                biases_fc = tf.get_variable('fc_biases', [8], initializer=tf.zeros_initializer(), regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))
                fc = tf.matmul(global_pool, weight_fc) + biases_fc

                mean, variance = tf.nn.moments(fc, [0, 1])
                fc1 = tf.nn.batch_normalization(fc, mean, variance, 0, 1, 0.0001)
                print(fc1)
            with tf.variable_scope('fc2'):
                mean, variance = tf.nn.moments(out, axes=[0, 1, 2])
                beta = tf.get_variable('beta', 64, tf.float32,
                                       initializer=tf.constant_initializer(0.0, tf.float32))
                gamma = tf.get_variable('gamma', 64, tf.float32,
                                        initializer=tf.constant_initializer(1.0, tf.float32))
                bn_layer = tf.nn.batch_normalization(out, mean, variance, beta, gamma, 0.0001)
                relu_layer = tf.nn.relu(bn_layer)
                print(relu_layer)
                #relu_layer = tf.reshape(relu_layer, (1, 3 * 3 * 64))
                global_pool = tf.reduce_mean(relu_layer, [1, 2])
                # # global_pool = ave_pool(relu_layer, k_size=(8, 8))
                print("global_pool", global_pool)

                weight_fc = tf.get_variable('fc_weight', [64, 3],
                                            initializer=tf.uniform_unit_scaling_initializer(factor=1.0),
                                            regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))
                biases_fc = tf.get_variable('fc_biases', [3],
                                            initializer=tf.zeros_initializer(),
                                            regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))
                fc = tf.matmul(global_pool, weight_fc) + biases_fc

                mean, variance = tf.nn.moments(fc, [0, 1])
                fc2 = tf.nn.batch_normalization(fc, mean, variance, 0, 1, 0.0001)
                print(fc2)

        self.reuse = True
        return fc1, fc2


# 0.89


