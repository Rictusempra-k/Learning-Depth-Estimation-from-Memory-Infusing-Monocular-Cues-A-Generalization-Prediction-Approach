from __future__ import print_function, absolute_import, division

import cv2
import os
import matplotlib.pyplot as plt
import xml.etree.ElementTree as ET
import json

class cityscapes():
    def __init__(self):
        self.city_img_path = "E:\\pyproject\\datasets\\CItySpaces\\leftImg8bit_trainvaltest\\leftImg8bit\\train\\aachen"
        self.city_label_path = "E:\\pyproject\\datasets\\CItySpaces\\gtFine_trainvaltest\\gtFine\\train\\aachen"


    def show(self):
        for im_name in os.listdir(self.city_img_path):
            im = cv2.imread(os.path.join(self.city_img_path, im_name))
            print("im_name", im_name)
            json_name = im_name[:-15]+"gtFine_polygons.json"
            print("json_name", json_name)

            self.load(json_name)


    # Load from given filename
    def load(self, name):
        filename = os.path.join(self.city_label_path, name)
        with open(filename, 'r') as f:
            jsonText = f.read()
            jsonDict = json.loads(jsonText)
            print("jsonDict", jsonDict)


ci = cityscapes()
ci.show()
