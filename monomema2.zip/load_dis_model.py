from read_KITTI import read_kitti
import tensorflow as tf
from lib.config.config import FLAGS, KITTI_classes
import numpy as np
import matplotlib.pyplot as plt
# from lib.config import config as cfg
import os

kitti = read_kitti()

x = tf.placeholder(tf.float32, [12])
y = tf.placeholder(tf.float32, [1])

weight = tf.get_variable(name='weight', shape=[12],
                            initializer=tf.uniform_unit_scaling_initializer(factor=1.0),
                            regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))

biases = tf.get_variable(name='biases', shape=[1],
                         initializer=tf.zeros_initializer(),
                         regularizer=tf.contrib.layers.l2_regularizer(scale=FLAGS.weight_decay))


def reg(x_, weights, bias):
    dis = tf.reduce_sum(tf.multiply(weights, x_)) + bias
    return dis

D = reg(x, weight, biases)

saver = tf.train.Saver()

with tf.Session() as sess:
    ckpt = tf.train.get_checkpoint_state('./data/ckpt')
    saver.restore(sess, ckpt.model_checkpoint_path)  # 注意此处路径前添加"./"
    kk =0
    w, b = sess.run([weight, biases])
    save_data = np.zeros(13)
    save_data[:12] = w
    save_data[-1] = b
    print(save_data)
    np.savetxt('./data/imagenet_weights/dis_weights.txt', save_data)

    while kk < 100:
        im, index, x_left, y_top, x_right, y_bottom, dis_x, dis_y, dis_z = kitti()
        for ii in range(len(im)):
            if index[ii] == 8:
                print(KITTI_classes[index[ii]])
                continue
            else:
                x_c = (x_left[ii] + x_right[ii]) / 2 / 1000
                y_c = y_bottom[ii] / 1000
                data = np.array(
                    [x_c, x_c ** 2, x_c ** 3, x_c ** 4, np.sqrt(x_c), y_c, y_c ** 2, y_c ** 3, y_c ** 4, np.sqrt(y_c),
                     x_c * y_c, x_c * (y_c ** 2)])
                dis_r = np.array([np.sqrt(dis_x[ii] ** 2 + dis_y[ii] ** 2 + dis_z[ii] ** 2) / 50])
                D_ = sess.run([D], feed_dict={x: data, y: dis_r})
                print(dis_r*50, D_[0]*50)
        kk += 1
