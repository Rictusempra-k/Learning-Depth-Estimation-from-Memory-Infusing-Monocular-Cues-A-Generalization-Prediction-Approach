# 把一个列表元素全变为int类型
int_fun = lambda x_list: [int(x) for x in x_list]
