name = "novamind"
