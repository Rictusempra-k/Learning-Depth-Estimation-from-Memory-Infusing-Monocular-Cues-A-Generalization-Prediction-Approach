from lib.datasets.kitti import kitti
from lib.config.config import FLAGS
import os
import cv2
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

kitti = kitti('test', '2017')

x, y, d = [], [], []
for ii in range(len(os.listdir(FLAGS.KITTI_Image_Training_PATH))):
    im, index, x_left, y_top, x_right, y_bottom, dis_x, dis_y, dis_z = kitti()  # (500, 375)
    # print(im.shape, index)

    for jj in range(len(index)):
        if index[jj] == 8:
            continue
        else:
            # y_img = (375 - y_bottom[jj]) / 375 * 1000 / 100
            # D_y = 10 * (0.693 * y_img - 0.16 * (y_img ** 2) + 0.0467 * (y_img ** 3) + 0.711)
            # D_x = abs((250 - (x_left[jj] + x_right[jj]) / 2)/500*600) / 600 * 10
            # D = np.sqrt(D_y ** 2 + D_x ** 2)

            x.append((x_left[jj] + x_right[jj]) / 2)
            y.append(375 - y_bottom[jj])
            d.append(np.sqrt(dis_x[jj] ** 2 + dis_y[jj] ** 2 + dis_z[jj] ** 2))
            # print(D, np.sqrt(dis_x[jj] ** 2 + dis_y[jj] ** 2 + dis_z[jj] ** 2))
            # cv2.imshow("t", im[0])
            # cv2.waitKey()

# plt.plot(y, d, "cs")
# plt.show()
ax = plt.subplot(111, projection='3d')  # 创建一个三维的绘图工程
ax.scatter(x, y, d, c='r')
ax.set_zlabel('Z')  # 坐标轴
ax.set_ylabel('Y')
ax.set_xlabel('X')
plt.show()
