from xml.dom import minidom
from lib.config.config import FLAGS
import os
import cv2


def xml(filename_, name_, x_min, y_min, x_max, y_max, dis_x, dis_y, dis_z, weight_, height_):
    print(filename_, name_, x_min, y_min, x_max, y_max, dis_x, dis_y, dis_z)
    doc = minidom.Document()
    kiitlist = doc.createElement("annotation")
    doc.appendChild(kiitlist)

    folder = doc.createElement("folder")
    folder.appendChild(doc.createTextNode("kitti"))
    kiitlist.appendChild(folder)

    filename = doc.createElement("filename")
    filename.appendChild(doc.createTextNode(filename_))
    kiitlist.appendChild(filename)

    def source():
        source = doc.createElement("source")

        data = doc.createElement("database")
        data.appendChild(doc.createTextNode("The KITTI Database"))

        annotation = doc.createElement("annotation")
        annotation.appendChild(doc.createTextNode("KITTI 2012"))

        image = doc.createElement("image")
        image.appendChild(doc.createTextNode("flickr"))

        # flickrid = doc.createElement("flickrid")
        # flickrid.appendChild(doc.createTextNode("325991873"))

        source.appendChild(data)
        source.appendChild(annotation)
        source.appendChild(image)
        # source.appendChild(flickrid)
        kiitlist.appendChild(source)

    source()

    # owner
    owner = doc.createElement("owner")

    flickrid = doc.createElement("flickrid")
    flickrid.appendChild(doc.createTextNode("archintent louisville"))

    owner_name = doc.createElement("name")
    owner_name.appendChild(doc.createTextNode("?"))
    owner.appendChild(flickrid)
    owner.appendChild(owner_name)
    kiitlist.appendChild(owner)

    def size():
        size = doc.createElement("size")

        width = doc.createElement("width")
        width.appendChild(doc.createTextNode(str(weight_)))

        height = doc.createElement("height")
        height.appendChild(doc.createTextNode(str(height_)))

        depth = doc.createElement("depth")
        depth.appendChild(doc.createTextNode("3"))

        size.appendChild(width)
        size.appendChild(height)
        size.appendChild(depth)
        kiitlist.appendChild(size)

    size()

    segmented = doc.createElement("segmented")
    segmented.appendChild(doc.createTextNode("0"))
    kiitlist.appendChild(segmented)


    def get_kitti(newbook):
        kitti = doc.createElement("object")

        title = doc.createElement("name")
        title.appendChild(doc.createTextNode(newbook["name"]))
        kitti.appendChild(title)
        title = doc.createElement("pose")
        title.appendChild(doc.createTextNode(newbook["pose"]))
        kitti.appendChild(title)
        title = doc.createElement("truncated")
        title.appendChild(doc.createTextNode(newbook["truncated"]))
        kitti.appendChild(title)
        title = doc.createElement("difficult")
        title.appendChild(doc.createTextNode(newbook["difficult"]))
        kitti.appendChild(title)

        box_name = doc.createElement("bndbox")
        xmin = doc.createElement("xmin")
        xmin.appendChild(doc.createTextNode(newbook["xmin"]))
        ymin = doc.createElement("ymin")
        ymin.appendChild(doc.createTextNode(newbook["ymin"]))

        xmax = doc.createElement("xmax")
        xmax.appendChild(doc.createTextNode(newbook["xmax"]))
        ymax = doc.createElement("ymax")
        ymax.appendChild(doc.createTextNode(newbook["ymax"]))

        box_name.appendChild(xmin)
        box_name.appendChild(ymin)
        box_name.appendChild(xmax)
        box_name.appendChild(ymax)
        kitti.appendChild(box_name)

        # dis
        dis_name = doc.createElement("distance")
        disx = doc.createElement("disx")
        disx.appendChild(doc.createTextNode(newbook["disx"]))
        disy = doc.createElement("disy")
        disy.appendChild(doc.createTextNode(newbook["disy"]))
        disz = doc.createElement("disz")
        disz.appendChild(doc.createTextNode(newbook["disz"]))

        dis_name.appendChild(disx)
        dis_name.appendChild(disy)
        dis_name.appendChild(disz)

        kitti.appendChild(dis_name)

        kiitlist.appendChild(kitti)

    for kk in range(len(name_)):
        get_kitti({"name": name_[kk], "pose": "Unspecified", "truncated": "0", "difficult": "0", "xmin": x_min[kk],
               "ymin": y_min[kk], "xmax": x_max[kk], "ymax": y_max[kk], "disx": dis_x[kk], "disy": dis_y[kk], "disz": dis_z[kk]})
    f = open("G:\\KITTI\\kitti\\Annotations\\" + str(filename_.split('.')[0]) + ".xml", "w")
    doc.writexml(f)
    f.close()

for label_name in os.listdir(FLAGS.test_label):
    filename = "{}.png".format(label_name.split('.')[0])
    print(filename)
    im = cv2.imread(os.path.join("G:\\KITTI\\kitti\\PNGImages", filename))
    h, w, d =im.shape
    print(w, h, d)
    f_label = open(os.path.join(FLAGS.test_label, label_name))
    (name_list, x_left, y_top, x_right, y_bottom, dis_x, dis_y, dis_z) = [], [], [], [], [], [], [], []
    for f in f_label:
        signal_obj = f.split(" ")
        if signal_obj[0] == 'DontCare':
            continue
        else:
            if float(signal_obj[4]) < 1:
                print('11111111111111111111111111111111                             11111', signal_obj[4])
                signal_obj[4] = '1.00'

            if float(signal_obj[5]) < 1:
                print('11111111111111111111111111111                                11111111', signal_obj[5])
                signal_obj[5] = '1.00'

            name_list.append(signal_obj[0])
            x_left.append(signal_obj[4])
            y_top.append(signal_obj[5])
            x_right.append(signal_obj[6])
            y_bottom.append(signal_obj[7])
            dis_x.append(signal_obj[11])
            dis_y.append(signal_obj[12])
            dis_z.append(signal_obj[13])
            print(signal_obj)

    xml(filename_=filename, name_=name_list, x_min=x_left, y_min=y_top, x_max=x_right, y_max=y_bottom, dis_x=dis_x, dis_y=dis_y, dis_z=dis_z, weight_=w, height_=h)

